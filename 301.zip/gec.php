<?php
include('config.php');
    if(isset($_POST['submit'])){
        $yenidomain=$_POST['domain'];
        foreach($_POST['veri'] as $zoneid){
            //print($zoneid);
            $olddomain=explode("|",$zoneid);
            $zoneidd=$olddomain[0];
            $oldomain=$olddomain[1];
            echo($oldomain);
            echo($zoneidd);
            $calistir=shell_exec('curl -X POST "https://api.cloudflare.com/client/v4/zones/'.$zoneidd.'/pagerules" -H "Authorization: Bearer '.$apikey.'" -H "X-Auth-Email:'.$mail.'" -H "Content-Type:application/json" --data \'{"targets": [{"target": "url","constraint":{"operator": "matches","value": "'.$oldomain.'/*"}}],"actions": [{"id": "forwarding_url","value": {"url": "http://www.'.$yenidomain.'/$1","status_code": 301}}],"priority": 1,"status": "active"}\'');
            $calistir=shell_exec('curl -X POST "https://api.cloudflare.com/client/v4/zones/'.$zoneidd.'/pagerules" -H "Authorization: Bearer '.$apikey.'" -H "X-Auth-Email:'.$mail.'" -H "Content-Type:application/json" --data \'{"targets": [{"target": "url","constraint":{"operator": "matches","value": "www.'.$oldomain.'/*"}}],"actions": [{"id": "forwarding_url","value": {"url": "http://www.'.$yenidomain.'/$1","status_code": 301}}],"priority": 1,"status": "active"}\'');

            echo($calistir);
            echo("ok");
         }
    }

?>
