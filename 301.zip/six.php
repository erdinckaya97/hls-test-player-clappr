<?php
include('config.php');
include('header.php');
?>
<form action="ssil.php" method="POST">
<input name="domain" placeholder="yenidomaini giriniz." type="text"/><br>

<input type="submit" name="submit" value="Onayla"><br>

<?php
//?per_page=20
foreach($_POST['veri'] as $zoneid){
$olddomain=explode("|",$zoneid);
$zoneidd=$olddomain[0]."/pagerules";
$oldomain=$olddomain[1];
$oldomain1=$olddomain[1];
$getzone=shell_exec('curl -X GET "https://api.cloudflare.com/client/v4/zones?name='.$oldomain1.'" -H "Authorization: Bearer '.$apikey.'" -H "X-Auth-Email:'.$mail.'" -H "Content-Type:application/json" ');
$zones=json_decode($getzone,true);

$z=$zones['result'];
foreach($z as $zone){
    //echo($zone['name']."<br>");
    $zoneid=$zone['id'];
    $calistir=shell_exec('curl -X GET "https://api.cloudflare.com/client/v4/zones/'.$zoneid.'/pagerules" -H "Authorization: Bearer '.$apikey.'" -H "X-Auth-Email:'.$mail.'" -H "Content-Type:application/json" ');
    $calistir1=json_decode($calistir,true);
    $y=$calistir1['result'];
    foreach($y as $ya){
        $yid=$ya['id'];

        echo('    <input type="checkbox" checked  id="kalite360" name="veri['.$yid.']" value="'.$zoneid.'|'.$yid.'|'.$zone['name'].'">    <label for="kalite">'.$zone['name'].'</label> <br>   ');
 
 
    }
    
    
  
       

   
    
}
}
    ?>

</form>
