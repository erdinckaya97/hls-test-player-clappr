<?php 
$apikey="g5CzHcoZp4LpsiM1qbzvu5DGals3R3YRzsodJ0lN"; 
$mail="trgoals@protonmail.com"; 

?>
