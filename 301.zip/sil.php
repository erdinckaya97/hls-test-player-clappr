<?php
include('config.php');
include('header.php');
print_r($_POST);
function sil($zoneidd1,$domain){
    include('config.php');
    $calistir1=shell_exec('curl -X DELETE "https://api.cloudflare.com/client/v4/zones/'.$zoneidd1.'/'.$domain.'" -H "Authorization: Bearer '.$apikey.'" -H "X-Auth-Email:'.$mail.'" -H "Content-Type:application/json"');
    echo("SİL:".$calistir1);

}
function ekle($zoneidd1,$domain,$yenidomain){
    include('config.php');
    $calistir=shell_exec('curl -X POST "https://api.cloudflare.com/client/v4/zones/'.$zoneidd1.'" -H "Authorization: Bearer '.$apikey.'" -H "X-Auth-Email:'.$mail.'" -H "Content-Type:application/json" --data \'{"targets": [{"target": "url","constraint":{"operator": "matches","value": "'.$domain.'/*"}}],"actions": [{"id": "forwarding_url","value": {"url": "http://www.'.$yenidomain.'/$1","status_code": 301}}],"priority": 1,"status": "active"}\'');
        echo("EKLE: ".$calistir);

    $calistir2=shell_exec('curl -X POST "https://api.cloudflare.com/client/v4/zones/'.$zoneidd1.'" -H "Authorization: Bearer '.$apikey.'" -H "X-Auth-Email:'.$mail.'" -H "Content-Type:application/json" --data \'{"targets": [{"target": "url","constraint":{"operator": "matches","value": "www.'.$domain.'/*"}}],"actions": [{"id": "forwarding_url","value": {"url": "http://www.'.$yenidomain.'/$1","status_code": 301}}],"priority": 1,"status": "active"}\'');
        echo("EKLE : ".$calistir2);

}
?>
<form action="ssil.php" method="POST">
<input name="domain" placeholder="yenidomaini giriniz." type="text"/><br>

<input type="submit" name="submit" value="Onayla"><br>

<?php
//?per_page=20
//foreach($_POST['veri'] as $zoneid){
$zoneid=$_POST['veri']['i'];
$yenidomain=$_POST['domain'];

$olddomain=explode("|",$zoneid);
$zoneidd=$olddomain[0]."/pagerules";
$oldomain=$olddomain[1];
$oldomain1=$olddomain[1];
$getzone=shell_exec('curl -X GET "https://api.cloudflare.com/client/v4/zones?name='.$oldomain1.'" -H "Authorization: Bearer '.$apikey.'" -H "X-Auth-Email:'.$mail.'" -H "Content-Type:application/json" ');
$zones=json_decode($getzone,true);
// eger eklenmiş kural yoksa ekleyerek sonlandır.



$z=$zones['result'];
foreach($z as $zone){
    //echo($zone['name']."<br>");
    $zoneid=$zone['id'];
    $calistir=shell_exec('curl -X GET "https://api.cloudflare.com/client/v4/zones/'.$zoneid.'/pagerules" -H "Authorization: Bearer '.$apikey.'" -H "X-Auth-Email:'.$mail.'" -H "Content-Type:application/json" ');
    $calistir1=json_decode($calistir,true);
    $y=$calistir1['result'];

    if($y==null){
    echo("boş");
    ekle($zoneidd,$oldomain1,$yenidomain);

    die();
   
}
    
    foreach($y as $ya){
        $yid=$ya['id'];
       
        $yenidomain=$_POST['domain'];
       
      
            //print($zoneid);
            //$olddomain=explode("|",$zoneid);
            $zoneidd=$zoneid."/pagerules";
            $oldomain=$yid;
            $oldomain1=$zone['name'];
            



       // echo('    <input type="checkbox" checked  id="kalite360" name="veri['.$yid.']" value="'.$zoneid.'|'.$yid.'|'.$zone['name'].'">    <label for="kalite">'.$zone['name'].'</label> <br>   ');
          //$calistir1=shell_exec('curl -X DELETE "https://api.cloudflare.com/client/v4/zones/'.$zoneidd.'/'.$oldomain.'" -H "Authorization: Bearer '.$apikey.'" -H "X-Auth-Email:'.$mail.'" -H "Content-Type:application/json"');
          sil($zoneidd,$oldomain);
          //ekle
         // $calistir=shell_exec('curl -X POST "https://api.cloudflare.com/client/v4/zones/'.$zoneidd.'" -H "Authorization: Bearer '.$apikey.'" -H "X-Auth-Email:'.$mail.'" -H "Content-Type:application/json" --data \'{"targets": [{"target": "url","constraint":{"operator": "matches","value": "'.$oldomain1.'/*"}}],"actions": [{"id": "forwarding_url","value": {"url": "http://www.'.$yenidomain.'/$1","status_code": 301}}],"priority": 1,"status": "active"}\'');
          ekle($zoneidd,$oldomain1,$yenidomain);
 
    }
//    echo('    <input type="checkbox" checked  id="kalite360" name="veri['.$zoneid.']" value="'.$zoneid.'|x|'.$zone['name'].'">    <label for="kalite">'.$zone['name'].'</label> <br>   ');

    
    
  
       

   
    
//}


}
    ?>

</form>
