<?php
include('config.php');
include('header.php');
function sil($zoneidd1,$domain){
    $calistir1=shell_exec('curl -X DELETE "https://api.cloudflare.com/client/v4/zones/'.$zoneidd1.'/'.$domain.'" -H "Authorization: Bearer '.$apikey.'" -H "X-Auth-Email:'.$mail.'" -H "Content-Type:application/json"');


}
function ekle($zoneidd1,$domain,$yenidomain){
    $calistir=shell_exec('curl -X POST "https://api.cloudflare.com/client/v4/zones/'.$zoneidd1.'" -H "Authorization: Bearer '.$apikey.'" -H "X-Auth-Email:'.$mail.'" -H "Content-Type:application/json" --data \'{"targets": [{"target": "url","constraint":{"operator": "matches","value": "'.$domain.'/*"}}],"actions": [{"id": "forwarding_url","value": {"url": "http://www.'.$yenidomain.'/$1","status_code": 301}}],"priority": 1,"status": "active"}\'');

    $calistir2=shell_exec('curl -X POST "https://api.cloudflare.com/client/v4/zones/'.$zoneidd.'" -H "Authorization: Bearer '.$apikey.'" -H "X-Auth-Email:'.$mail.'" -H "Content-Type:application/json" --data \'{"targets": [{"target": "url","constraint":{"operator": "matches","value": "www.'.$domain.'/*"}}],"actions": [{"id": "forwarding_url","value": {"url": "http://www.'.$yenidomain.'/$1","status_code": 301}}],"priority": 1,"status": "active"}\'');

}
    if(isset($_POST['submit'])){
        $yenidomain=$_POST['domain'];
        $i=1;
        foreach($_POST['veri'] as $zoneid){
            //print($zoneid);
            $olddomain=explode("|",$zoneid);
            $zoneidd=$olddomain[0]."/pagerules";
            $oldomain=$olddomain[1];
            $oldomain1=$olddomain[2];
           

           //sil 
            //$calistir1=shell_exec('curl -X DELETE "https://api.cloudflare.com/client/v4/zones/'.$zoneidd.'/'.$oldomain.'" -H "Authorization: Bearer '.$apikey.'" -H "X-Auth-Email:'.$mail.'" -H "Content-Type:application/json"');
           sil($zoneidd,$oldomain1);
            //ekle
           // $calistir=shell_exec('curl -X POST "https://api.cloudflare.com/client/v4/zones/'.$zoneidd.'" -H "Authorization: Bearer '.$apikey.'" -H "X-Auth-Email:'.$mail.'" -H "Content-Type:application/json" --data \'{"targets": [{"target": "url","constraint":{"operator": "matches","value": "'.$oldomain1.'/*"}}],"actions": [{"id": "forwarding_url","value": {"url": "http://www.'.$yenidomain.'/$1","status_code": 301}}],"priority": 1,"status": "active"}\'');
            ekle($zoneidd,$oldomain1,$yenidomain);

          
           
                //$calistir=shell_exec('curl -X DELETE "https://api.cloudflare.com/client/v4/zones/'.$zoneidd.'/'.$oldomain.'" -H "Authorization: Bearer '.$apikey.'" -H "X-Auth-Email:'.$mail.'" -H "Content-Type:application/json"');
             //ekle www s
                //$calistir2=shell_exec('curl -X POST "https://api.cloudflare.com/client/v4/zones/'.$zoneidd.'" -H "Authorization: Bearer '.$apikey.'" -H "X-Auth-Email:'.$mail.'" -H "Content-Type:application/json" --data \'{"targets": [{"target": "url","constraint":{"operator": "matches","value": "www.'.$oldomain1.'/*"}}],"actions": [{"id": "forwarding_url","value": {"url": "http://www.'.$yenidomain.'/$1","status_code": 301}}],"priority": 1,"status": "active"}\'');
    
           
           

	echo(“ok”);
         }
        
    }

?>
