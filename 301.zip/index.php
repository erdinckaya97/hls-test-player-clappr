<?php
include('config.php');
include('header.php');
?>
<textarea oninput="s();" id="siteler">
</textarea>

<select  style=" position: absolute;

right: 200px;width:200px" id="istekler"  name="istekler" size="20">  
  
</select>  
<input name="domain" placeholder="yenidomaini giriniz." type="text"/>


<input type="submit" name="submit" onclick="start();" value="Onayla"><br>


<?php


$getzone=shell_exec('curl -X GET "https://api.cloudflare.com/client/v4/zones?per_page=1000" -H "Authorization: Bearer '.$apikey.'" -H "X-Auth-Email:'.$mail.'" -H "Content-Type:application/json" ');
$zones=json_decode($getzone,true);


$z=$zones['result'];
//echo($getzone);
foreach($z as $zone){
    //echo($zone['name']."<br>");
    
    $zoneid=$zone['id'];

    echo('    <input type="checkbox"   id="'.$zone["name"].'." name="veri['.$zoneid.']" value="'.$zoneid.'|'.$zone['name'].'">    <label for="kalite">'.$zone['name'].'</label> <br>   ');
 
 
    
}
    ?>

<script src="https://code.jquery.com/jquery-3.5.1.min.js"></script>
<script>
function start(){
    var i = 1;
    var markedCheckbox = document.querySelectorAll('input[type="checkbox"]:checked');
    var domain=document.getElementsByName("domain")[0].value
    var selectElement = document.getElementById('istekler');
    
    for (var checkbox of markedCheckbox) {
    $.ajax({
        url: "sil.php", method:"post", data: {'veri[i]': checkbox.value,'domain':domain}
       

    })
    var x = document.getElementById("istekler");
  var option = document.createElement("option");
  const myArray = checkbox.value.split("|");
let word = myArray[1];
    option.text = word;
    x.add(option);
    i=i+1;
    }

       
}
function s(){
var siteler = $('textarea#siteler').val();
listemiz=siteler.split("\n");
for(i in listemiz){
    var a = (listemiz[i]);
    
          document.getElementById(a+".").checked=true;


    
}
}
</script>